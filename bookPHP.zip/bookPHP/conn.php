<?php  

$conn=mysql_connect("localhost","root","root");
	//连接数据库服务器
	mysql_select_db("db_book",$conn);
	//连接数据库
	mysql_query("set names utf8");
	//对数据库中编码进行转码
?>