<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <title>图书信息管理系统</title>
        <link rel="stylesheet" href="lib/bootstrap/css/bootstrap.css">
        <link rel="stylesheet" href="css/main.css">
        <!-- [inf lt IE 9] >
			<script src="lib/html5shiv/dist/html5shiv.min.js"></script>
			<script src="lib/Respond/dest/respond.min.js"></script>
        <![endif] -->
    </head>
    	<?php 
    		$id=$_GET['id'];
    		// echo $id;
    		include('conn.php');
    		$sql="select * from tb_book where id=$id";
    		$result=mysql_query($sql);
    		$array=mysql_fetch_array($result);
    		// echo "<pre>";
    		// print_r($array) ;
    		// echo "</pre>";
    	 ?>
    <body>
    <!-- 页头 -->
    <header id="header">
    	<div class="container">
    		<div class="img-banner"></div>
    	</div>
    </header>
    <!-- 导航 -->
    <nav class="navbar navbar-default navbar-static-top">
      <div class="container">
         	<div class="collapse navbar-collapse" id="nav-list">
     			<ul class="nav navbar-nav navbar-static-top">
     				<li ><a href="index.html" >首页</a></li>
     				<li class="active"><a href="#">图书信息添加</a></li>
     				<li><a href="update.html">图书信息管理</a></li>
     				
     			</ul>
     			<ul class="nav navbar-nav navbar-right hidden-sm" id="btn">
     			    <li>
     			     	<a href="#"><?php echo "欢迎您：".$_SESSION['user']; ?></a>
     			     </li>
     			     <li>
     					<a href="#">退出</a>
     			     </li>
     			</ul>
     		</div>
     		
      </div>
    </nav>
    <!-- 搜索 -->
	<!-- 主体 -->
	<section class="list">
		<div class="container">
			 	<div class="panel panel-default">
			 	      <!-- Default panel contents -->
			 	      <div class="panel-heading"><h3>书名《 <?php echo $array['books']; ?>》</h3></div>
			 	      <div class="panel-body">
			 	      	<h4>图书简介</h4>	
			 	        <p><?php echo $array['synosis']; ?></p>
			 	      </div>

			 	      <!-- Table -->
			 	      <table class="table">
			 	        <tbody>
			 	          <tr>
			 	            <th scope="row">上传日期</th>
			 	            <td><?php echo $array['date']; ?></td>
			 	            <th scope="row">类别</th>
			 	            <td><?php echo $array['sort']; ?></td>
			 	            <th scope="row">语言</th>
			 	            <td><?php echo $array['talk']; ?></td>
			 	          </tr>
			 	          <tr>
			 	            <th scope="row" >文稿存储位置</th>
			 	            <td colspan="5"><a target="_blank" href=""><?php echo $array['bookpath']; ?></a></td>
			 	          </tr>
			 	          <tr>
			 	            <th scope="row" >程序存储位置</th>
			 	            <td colspan="5"><a target="_blank" href=""><?php echo $array['programpath']; ?></td>
			 	          </tr>
			 	          <tr>
			 	            <th scope="row" >录像存储位置</th>
			 	            <td colspan="5"><a target="_blank" href=""><?php echo $array['videopath']; ?></a></td>
			 	          </tr>
			 	          <tr>
			 	            <th scope="row" >目录</th>
			 	            <td colspan="5">
			 	            	<?php echo $array['catalog']; ?>
							</td>
			 	          </tr>
			 	        </tbody>
			 	      </table>
			 	    </div>
			 	  </div>
			  </div>
			</div>
		</div>
	</section>
	<!-- 页脚 -->
	<footer class="footer">
		<div class="container text-center">
			<p class="">长春职业技术学院  信息技术分院 移动应用开发专业</p>
		</div>
	</footer>
	<!-- 模态框 -->
	<!-- 登录模态框 -->
	<div class="modal fade" id="login_form" tabindex="-1" role="dialog" aria-labelledby="login_form_title">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title" id="login_form_title">登录</h4>
	      </div>
	      <div class="modal-body">
	        <form>
	          <div class="form-group">
	            <label for="recipient-name" class="control-label">用户名：</label>
	            <input type="text" class="form-control" id="recipient-name">
	          </div>
	          <div class="form-group">
	            <label for="message-text" class="control-label">密码：</label>
	            <input type="text" class="form-control" id="message-text">
	          </div>
	        </form>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
	        <button type="button" class="btn btn-primary">登录</button>
	      </div>
	    </div>
	  </div>
	</div>
	<!-- 注册模态框 -->
	<div class="modal fade" id="register_form" tabindex="-1" role="dialog" aria-labelledby="register_form_title">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title" id="register_form_title">注册</h4>
	      </div>
	      <div class="modal-body">
	        <form>
	          <div class="form-group">
	            <label for="recipient-name" class="control-label">用户名：</label>
	            <input type="text" class="form-control" id="recipient-name">
	          </div>
	          <div class="form-group">
	            <label for="message-text" class="control-label">密码：</label>
	            <input type="text" class="form-control" id="message-text">
	          </div>
	        </form>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
	        <button type="button" class="btn btn-primary">注册</button>
	      </div>
	    </div>
	  </div>
	</div>
     <script src="lib/jquery/jquery.js"></script>
     <script src="lib/bootstrap/js/bootstrap.js"></script>
    </body>
</html>