<?php 
session_start();
	// $GET=$_GET;
	// print_r($GET);
	header("content-type:text/html;charset=utf-8"); //设置页面编码
	include('conn.php');	//包含数据库连接文件
	if(isset($_POST["user"]) && isset($_POST["pwd"])){
		if ($_POST["user"]!=null && $_POST["pwd"]!=null) {
		$user=$_POST["user"];
		$pwd=$_POST["pwd"];
		$sql="select * from tb_login where user='".$user."'and pwd = '".$pwd."'";
		$result=mysql_query($sql);
		if(!mysql_num_rows($result)==0){
			$_SESSION['user']=$user;
			$_SESSION['isok']="ok";
			echo "<script language='javascript'>";
			echo " location='index.php';";
			echo " </script>";
		}else{
			echo "帐号密码有误!";
			echo "<a href='index.php'>返回重新登录!</a>";
			exit;
		}
		}
	}
	



	
 ?>