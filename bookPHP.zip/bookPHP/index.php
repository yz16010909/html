<?php 
session_start();
header("content-type:text/html;charset=utf-8");


	// require 'conn.php';
	include("conn.php");
	// var_dump($conn);
	// $result=mysql_query("select * from tb_book");
 	// $lenovo=mysql_fetch_array($result,MYSQL_ASSOC);
 	// echo "<pre>";
 	// 	print_r($lenovo);
 	// 	echo "</pre>";
 // 	while ($lenovo=mysql_fetch_row($result)) {
 // 		echo "<pre>";
 // 		print_r($lenovo);
 // 		echo "</pre>";
 // 	}
 // 	echo mysql_num_rows($result);
 	$select1=mysql_query("select * from tb_book where talk='PHP' order by id DESC limit 2",$conn);
 	$select2=mysql_query("select * from tb_book where talk='C' order by id desc limit 2",$conn);
 	$select3=mysql_query("select * from tb_book where talk='.net' order by id desc limit 2",$conn);
 	$select4=mysql_query("select * from tb_book where talk='JAVA' order by id desc limit 2",$conn);
 	$select5=mysql_query("select * from tb_book where talk='VB' order by id desc limit 2",$conn);
 	$select6=mysql_query("select * from tb_book where talk='其它' order by id desc limit 2",$conn);
 	// $select=mysql_query("select * from tb_book",$conn);
 	// $array=msql_fetch_array($select);
 	include_once("view/index.html");
  ?>