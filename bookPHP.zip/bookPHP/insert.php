<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <title>图书信息管理系统</title>
        <link rel="stylesheet" href="lib/bootstrap/css/bootstrap.css">
        <link rel="stylesheet" href="css/main.css">
        <!-- [inf lt IE 9] >
			<script src="lib/html5shiv/dist/html5shiv.min.js"></script>
			<script src="lib/Respond/dest/respond.min.js"></script>
        <![endif] -->
        <?php 
        	include('conn.php');
        	$select1=mysql_query("select * from tb_sort");
        	// var_dump($select);
        	
         ?>
    </head>
    <body>
    <!-- 页头 -->
    <header id="header">
    	<div class="container">
    		<div class="img-banner"></div>
    	</div>
    </header>
    <!-- 导航 -->
    <nav class="navbar navbar-default navbar-static-top">
      <div class="container">
         	<div class="collapse navbar-collapse" id="nav-list">
     			<ul class="nav navbar-nav navbar-static-top">
     				<li ><a href="index.php" >首页</a></li>
     				<li class="active"><a href="#">图书信息添加</a></li>
     				<li><a href="update.php">图书信息管理</a></li>
     				
     			</ul>
     			<ul class="nav navbar-nav navbar-right hidden-sm" id="btn">
     			    <li>
     			     	<a href="#"><?php echo "欢迎您：".$_SESSION['user']; ?></a>
     			     </li>
     			     <li>
     					<a href="stop.php">退出</a>
     			     </li>
     			</ul>
     		</div>
     		
      </div>
    </nav>
    <!-- 搜索 -->
	<!-- 主体 -->
	<section class="list">
		<div class="container">
			<div class="panel panel-default">
			  <div class="panel-heading">
			    <h3 class="panel-title text-center">添加图书信息</h3>
			  </div>
			  <div class="panel-body">

			 	<form class="form-horizontal" action="insert_ok.php" method="post" enctype="multipart/form-data" name="form" id="form">
			 	  <div class="form-group">
			 	    <label for="books" class="col-sm-2 control-label">书名</label>
			 	    <div class="col-sm-10">
			 	      <input name="books" type="text" class="form-control" id="books" placeholder="图书名称">
			 	    </div>
			 	  </div>

			 	  <div class="form-group">
					  <label for="sort" class="col-sm-2 control-label">类别</label>
					 
					  <div class="col-sm-10">			  	
					 	  <select class="form-control" name="sort" id="sort">
		 	  		<?php  
					 while ($array1=mysql_fetch_array($select1)) {
        		// echo $array1["sort"]."<br>";
        	?>
					 	    <option><?php echo $array1["sort"]; ?> </option>
					 	    <?php } ?>
					 	  </select>
					  </div>
			 	  </div>

				  	  <div class="form-group">
				 		  <label for="talk" class="col-sm-2 control-label">语言</label>
				 		  <div class="col-sm-10">			  	
				 		 	  <select class="form-control" name="talk" id="talk">
				 		 	    <?php 
				 		 	    	$select2=mysql_query("select * from tb_program");
				 		 	    	while ($arr=mysql_fetch_array($select2)) {
				 		 	 		
				 		 	     ?>
				 		 	    <option><?php echo $arr['talk']; ?></option>
				 		 	
				 		 	    <?php } ?>
				 		 	  </select>
				 		  </div>
				  	  </div>

			 	  <div class="form-group">
			 	    <label for="synopsis" class="col-sm-2 control-label">简介</label>
			 	    <div class="col-sm-10">
			 	      <input name="synopsis" type="text" class="form-control" id="synopsis" placeholder="内容简介">
			 	    </div>
			 	  </div>

			 	   <div class="form-group">
			 	    <label for="synopsis" class="col-sm-2 control-label">目录</label>
			 	    <div class="col-sm-10">
			 	      <textarea name="catalog" id="catalog" class="form-control" rows="3" placeholder="图书目录"></textarea>
			 	    </div>
			 	  </div>

			 	  <div class="form-group">
			 	    <label for="bookpath" class="col-sm-2 control-label">文件路径</label>
			 	    <div class="col-sm-10">
			 	      <input name="bookpath" type="text" class="form-control" id="bookpath" placeholder="路径">
			 	    </div>
			 	  </div>
			 	  
			 	   <div class="form-group">
			 	    <label for="programpath" class="col-sm-2 control-label">程序路径</label>
			 	    <div class="col-sm-10">
			 	      <input name="programpath" type="text" class="form-control" id="programpath" placeholder="路径">
			 	    </div>
			 	  </div>

			 	   <div class="form-group">
			 	    <label for="videopath" class="col-sm-2 control-label">录像路径</label>
			 	    <div class="col-sm-10">
			 	      <input name="videopath" type="text" class="form-control" id="videopath" placeholder="路径">
			 	    </div>
			 	  </div>
			 	  <div class="form-group">
			 	    <div class="col-sm-offset-6 col-sm-10">
			 	      <button type="submit" class="btn btn-default">提交</button>
			 	       <button type="resert" class="btn btn-default">取消</button>
			 	    </div>
			 	  </div>
			 	</form>
			  </div>
			</div>
		</div>
	</section>
	<!-- 页脚 -->
	<footer class="footer">
		<div class="container text-center">
			<p class="">长春职业技术学院  信息技术分院 移动应用开发专业</p>
		</div>
	</footer>
	<!-- 模态框 -->
	<!-- 登录模态框 -->
	<div class="modal fade" id="login_form" tabindex="-1" role="dialog" aria-labelledby="login_form_title">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title" id="login_form_title">登录</h4>
	      </div>
	      <div class="modal-body">
	        <form>
	          <div class="form-group">
	            <label for="recipient-name" class="control-label">用户名：</label>
	            <input type="text" class="form-control" id="recipient-name">
	          </div>
	          <div class="form-group">
	            <label for="message-text" class="control-label">密码：</label>
	            <input type="text" class="form-control" id="message-text">
	          </div>
	        </form>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
	        <button type="button" class="btn btn-primary">登录</button>
	      </div>
	    </div>
	  </div>
	</div>
	<!-- 注册模态框 -->
	<div class="modal fade" id="register_form" tabindex="-1" role="dialog" aria-labelledby="register_form_title">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title" id="register_form_title">注册</h4>
	      </div>
	      <div class="modal-body">
	        <form>
	          <div class="form-group">
	            <label for="recipient-name" class="control-label">用户名：</label>
	            <input type="text" class="form-control" id="recipient-name">
	          </div>
	          <div class="form-group">
	            <label for="message-text" class="control-label">密码：</label>
	            <input type="text" class="form-control" id="message-text">
	          </div>
	        </form>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
	        <button type="button" class="btn btn-primary">注册</button>
	      </div>
	    </div>
	  </div>
	</div>
     <script src="lib/jquery/jquery.js"></script>
     <script src="lib/bootstrap/js/bootstrap.js"></script>
    </body>
</html>