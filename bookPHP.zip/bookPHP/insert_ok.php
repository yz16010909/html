<?php 
	header("content-type:text/html;charset=utf-8"); //设置页面编码
	include('conn.php');
	if (isset($_POST)) {
		$sort=$_POST['sort'];
		$talk=$_POST['talk'];
		$books=$_POST['books'];
		$synosis=$_POST['synosis'];
		$catalog=$_POST['catalog'];
		$bookpath=$_POST['bookpath'];
		$programpath=$_POST['programpath'];
		$videopath=$_POST['videopath'];
		$date=date('Y-m-d');
		$insert=mysql_query("insert into tb_book(sort,talk,books,synosis,catalog,bookpath,programpath,videopath,date)values('$sort','$talk','$books','$synosis','$catalog','$bookpath','$programpath','$videopath','$date')",$conn);
		// var_dump($insert);
		// echo mysql_error();
		if ($insert) {
			echo "<script>alert('chengg');window.location.href='index.php'</script>";
		}else{
			echo "<script>alert('shi');window.location.href='insert.php'</script>";
		}
	}
 ?>