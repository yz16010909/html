<?php 
	// $GET=$_GET;
	// print_r($GET);
	header("content-type:text/html;charset=utf-8"); //设置页面编码
	include('conn.php');	//包含数据库连接文件
	if (isset($_POST['user']) and isset($_POST['pwd'])) {	//判断用户名密码是否存在
		if ($_POST['user']!=null and $_POST['pwd']!=null) {	//判断用户名密码是否不为空
			$select=mysql_query("select * from tb_login where user='".$_POST['user']."'",$conn); 	//查询数据库中是否存在该用户名
			if (mysql_num_rows($select)==0) {	//判断查询结果是否为0
				$insert=mysql_query("insert into tb_login(user,pwd) values('".$_POST['user']."','".$_POST['pwd']."')",$conn);
				if ($insert) {	//判断添加操作是否执行成功
					echo "<script>alert('恭喜你注册成功!');window.location.href='index.php'</script>";
				}else{
					echo "<script>alert('注册失败!');windos.location.href='index.php'</script>";
				}
			}else{
				echo "<script>alert('用户名已存在,请重新输入!');windos.location.href='index.php</script>";
			}	
		}else{
			echo "<script>alert('请输入完整的注册信息!');window.location.href='index.php'</script>";
		}	
	}
 ?>