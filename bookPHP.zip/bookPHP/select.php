<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <title>图书信息管理系统</title>
        <link rel="stylesheet" href="lib/bootstrap/css/bootstrap.css">
        <link rel="stylesheet" href="css/main.css">
        <!-- [inf lt IE 9] >
			<script src="lib/html5shiv/dist/html5shiv.min.js"></script>
			<script src="lib/Respond/dest/respond.min.js"></script>
        <![endif] -->
    </head>
    <body>
    <!-- 页头 -->
    <header id="header">
    	<div class="container">
    		<div class="img-banner"></div>
    	</div>
    </header>
    <!-- 导航 -->
    <nav class="navbar navbar-default navbar-static-top">
      <div class="container">
         	<div class="collapse navbar-collapse" id="nav-list">
     			<ul class="nav navbar-nav navbar-static-top">
     				<li class="active"><a href="index.php" >首页</a></li>
     				<li><a href="insert.php">图书信息添加</a></li>
     				<li><a href="update.php">图书信息管理</a></li>
     				
     			</ul>
     			<ul class="nav navbar-nav navbar-right hidden-sm" id="btn">
     			<?php if($_SESSION['isok']=="ok"){ 
     				echo "<li>欢迎您:".$_SESSION['user']."</li>";
     			}else{     					    				
     			?>
     				<li>
     					<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#login_form">
     					  登录
     					</button>
     				<!-- <a href="courses.html">注册</a> -->
     				</li>
     				<li>
						<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#register_form">
     					  注册
     					</button>
     				</li>
     				<?php } ?>
				</ul>
     		</div>
     		
      </div>
    </nav>
    <!-- 搜索 -->
    <div class="seach">
    	<div class="container">
     		<div class="panel panel-default">

     		  <div class="panel-body">
     		  <div class="row">
     		  	<div class="col-md-2">
     		  		<h4 class="text-center"> 图书搜索：</h4>
     		  	</div>
     		  	<div class="col-md-2">
	     		    <form method="post" name="list" id="list" form-control>
	     		      <div class="form-group">
	     		        
	     		        <select class="form-control" name="select1" onchange="javascript:list.submit()">
	     		          <option selected="selected">请选择</option>
	     		          <option value="Famous_Id">类别</option>
	     		          <option value="Famous_Ids">语言</option>
	     		        </select>
	     		      </div>
	     		    </form>
	     		 
     		    </div>
					<div class="col-md-4">
     		     <form id="form1" name="form1" action="select.php" method="post" form-control>
	     		     <div class="form-group">
							<select class="form-control" name="select2">
							  <option selected="selected">请选择</option>
							  <?php 
							  	include_once("conn.php");
							  		if (isset($_POST['select1'])) {
							  			$select=$_POST['select1'];
							  			if ($select=="Famous_Id") {
							  				$sel=mysql_query("select * from tb_sort",$conn);
							  				/**/
							  				while ($arr=mysql_fetch_array($sel)) {
							  					?>
							  					<option value="<?php echo $arr['sort'];?>"><?php echo $arr['sort'];?></option>
							  					
							  				<?php }
							  					}else if($select=="Famous_Ids"){
							  					$sel1=mysql_query("select * from tb_program",$conn);
							  					while ($arr1=mysql_fetch_array($sel1)) {
							  						?>
							  						<option value="<?php echo $arr1['talk'];?>"><?php echo $arr1['talk'];?></option>
							  					<?php 
							  						}
							  			}
							  		}
							   ?>
							  <option value="">内容1</option>
							  <option value="">内容2</option>
							</select>
	     		     </div>
	     		    
     		  	</div>
     		  	<div class="col-md-1">
     		  		 <button type="submit" class="btn btn-default">选择</button>
     		     </form>
     		  	</div>
     		  </div>
     		  </div>

     		</div>  
    	</div>
    </div>
	<!-- 主体 -->
	<section class="list">
		<div class="container">
			<div class="panel panel-default">
			  <div class="panel-heading">
			    <h3 class="panel-title text-center">查询结果如下</h3>
			  </div>
			  <div class="panel-body">
			  <?php 
			  	if (isset($_POST['select2'])) {
			  		$key=$_POST['select2'];
			  		$selec=mysql_query("select * from tb_book where sort='$key'or talk='$key'",$conn);
			  		while ($array=mysql_fetch_array($selec)) {
			  			?>
			 		<div class="alert alert-info" role="alert">
			 			<a href="define.php?id=<?php echo $array['id']; ?>" class="alert-link">书名：<?php echo $array['books']; ?></a>
			 			<u>类别：<?php echo $array['sort']; ?></u>
			 			<em>语言：<?php echo $array['talk']; ?></em>
			 			<small class="pull-right"><?php echo $array['date']; ?></small>
			 		</div>
			  			
			  		<?php }
			  	}
			   ?>
			  </div>
			</div>
		</div>
	</section>
	<!-- 页脚 -->
	<footer class="footer">
		<div class="container text-center">
			<p class="">长春职业技术学院  信息技术分院 移动应用开发专业</p>
		</div>
	</footer>
	<!-- 模态框 -->
	<!-- 登录模态框 -->
	<div class="modal fade" id="login_form" tabindex="-1" role="dialog" aria-labelledby="login_form_title">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title" id="login_form_title">登录</h4>
	      </div>
	      <div class="modal-body">
	        <form id="form2" name="form2" action="enter_ok.php" method="post">
	          <div class="form-group">
	            <label for="recipient-name" class="control-label">用户名：</label>
	            <input type="text" class="form-control" id="recipient-name" name="user">
	          </div>
	          <div class="form-group">
	            <label for="message-text" class="control-label">密码：</label>
	            <input type="text" class="form-control" id="message-text" name="pwd">
	          </div>
	        
	      </div>
	      <div class="modal-footer">
	        <button type="submit" class="btn btn-default" data-dismiss="modal">关闭</button>
	        <button type="submit" class="btn btn-primary">登录</button>
	      </div>
	       </form>
	    </div>
	  </div>
	</div>
	<!-- 注册模态框 -->
	<div class="modal fade" id="register_form" tabindex="-1" role="dialog" aria-labelledby="register_form_title">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title" id="register_form_title">注册</h4>
	      </div>
	      <div class="modal-body">
	        <form id="form1" name="form1" action="login_ok.php" method="post">
	          <div class="form-group">
	            <label for="recipient-name" class="control-label">用户名：</label>
	            <input type="text" class="form-control" id="recipient-name" name="user">
	          </div>
	          <div class="form-group">
	            <label for="message-text" class="control-label">密码：</label>
	            <input type="password" class="form-control" id="message-text" name="pwd">
	          </div>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
	        <button type="submit" class="btn btn-primary">注册</button>
	      </div>
	        </form>
	    </div>
	  </div>
	</div>
     <script src="lib/jquery/jquery.js"></script>
     <script src="lib/bootstrap/js/bootstrap.js"></script>
    </body>
</html>
