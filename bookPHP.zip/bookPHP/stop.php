<?php 
	session_start();
	
		unset($_SEEION);		
	
	session_destroy();
	header("location:index.php");
 ?>