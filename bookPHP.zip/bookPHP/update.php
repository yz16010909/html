<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <title>图书信息管理系统</title>
        <link rel="stylesheet" href="lib/bootstrap/css/bootstrap.css">
        <link rel="stylesheet" href="css/main.css">
        <!-- [inf lt IE 9] >
			<script src="lib/html5shiv/dist/html5shiv.min.js"></script>
			<script src="lib/Respond/dest/respond.min.js"></script>
        <![endif] -->
    </head>
    <body>
    
    <!-- 页头 -->
    <header id="header">
    	<div class="container">
    		<div class="img-banner"></div>
    	</div>
    </header>
    <!-- 导航 -->
    <nav class="navbar navbar-default navbar-static-top">
      <div class="container">
         	<div class="collapse navbar-collapse" id="nav-list">
     			<ul class="nav navbar-nav navbar-static-top">
     				<li><a href="index.php" >首页</a></li>
     				<li><a href="insert.php">图书信息添加</a></li>
     				<li class="active"><a href="#">图书信息管理</a></li>
     				
     			</ul>
     			<ul class="nav navbar-nav navbar-right hidden-sm" id="btn">
     				<li>
     					<a href="#">欢迎您：会员名</a>
     				</li>
     				<li>
						<a href="#">退出</a>
     				</li>
				</ul>
     		</div>
     		
      </div>
    </nav>
	<!-- 主体 -->
	<section class="list">
		<div class="container">
			<div class="panel panel-default">
			  <div class="panel-heading">
			    <h3 class="panel-title text-center">图书信息管理</h3>
			  </div>
			  <div class="panel-body">
			 
				<table class="table table-hover">
				      <thead>
				        <tr>
				          <th>序号</th>
				          <th>书名</th>
				          <th>修改</th>
				          <th>删除</th>
				        </tr>
				      </thead>
				      <tbody>
				      <?php include_once('conn.php');
				      $sqq="select count(*) from tb_book";
				      $res=mysql_query($sqq,$conn);
				     $array=mysql_fetch_row($res); //获取总的记录个数
				     $num=$array[0];
				     //echo $num;
				     //每页显示的行数
				     $rowsperpage = 3;
				     //获得总页数
				     $totalpages=ceil($num/$rowsperpage);
				     //获取当前页数或设置默认值
				     if (isset($_GET['currentpage'])&& is_numeric($_GET['currentpage'])) {
				     	$currentpage=(int) $_GET['currentpage'];
				     }else{
				     	$currentpage=1;
				     }

				     //如果当前页数大于总数
				     if ($currentpage>$totalpages) {
				     	//设置当前页数到最后一页
				     	$currentpage=$totalpages;
				     }
				     //如果当前页面小于第一页
				     if ($currentpage<1) {
				     	$currentpage=1;
				     }
				     //当前页数减一乘以每行个数，也就是当前的总个数
				     $offset=($currentpage - 1)*$rowsperpage;

    	$sql=mysql_query("select * from tb_book order by id desc limit $offset,$rowsperpage");
    	// $arr=mysql_fetch_array($sql); 索引和关联
    	while ( $arr=mysql_fetch_assoc($sql)) {//仅关联
    	 	// echo $arr['books']."<br>";
    	  ?>
				        <tr>
				          <th scope="row"><?php echo $arr['id']."<br>"; ?></th>
				          <td><?php echo $arr['books']."<br>"; ?></td>
				          <td><a href="update_ok.php?id=<?php echo $arr['id']; ?>">修改</a></td>
				          <td><a href="delete.php?id=<?php echo $arr['id']; ?>">删除</a></td>
				        </tr>
		<?php  } ?>
				        
				      </tbody>
				  </table>
				  <nav aria-label="Page navigation" class="pull-right" >
				       <ul class="pagination">
				  <?php 
				  		//建立分页连接
				  		$range=3;
				  //如果当前页不是page1 就不显示back link
				  if ($currentpage>1) {
				  	echo '<li>
				           <a href="'.$_SERVER['PHP_SELF'].'?currentpage=1" aria-label="Previous">
				             <span aria-hidden="true">&laquo;</span>
				           </a> 
				         </li>';
				  	// $prevpage=$currentpage-1;
				  	// echo "<a href='{$_SERVER['PHP_SELF']}?currentpage=$prevpage'></a>";
				
				  	$prevpage=$currentpage-1;
				  	echo '<li>
				           <a href="'.$_SERVER['PHP_SELF'].'?currentpage=1" aria-label="Previous">
				             <span aria-hidden="true">&lt;</span>
				           </a> 
				         </li>';
				  }
				   ?>
				  <!-- 分页 -->
				         <!-- <li>
				           <a href="{$_SERVER['PHP_SELF']}?currentpage=1" aria-label="Previous">
				             <span aria-hidden="true">&laquo;</span>
				           </a> 
				         </li>-->
					<?php 
						for ($x=($currentpage-$range); $x <(($currentpage+$range)+1) ; $x++) { 
							if(($x>0)&&($x<=$totalpages)){
								if ($x==$currentpage) {
									echo "<li class='active'><a href='#'>$x</a></li>";
								}else{
									echo "<li><a href='{$_SERVER['PHP_SELF']}?currentpage=$x'>$x</a></li>";
								}
							}
						}
					 ?>
				         <!-- <li><a href="#">1</a></li>
				         <li><a href="#">2</a></li>
				         <li><a href="#">3</a></li>
				         <li><a href="#">4</a></li>
				         <li><a href="#">5</a></li> -->
				         <!-- <li>
				           <a href="#" aria-label="Next">
				             <span aria-hidden="true">&raquo;</span>
				           </a>
				         </li> -->
				<?php 
					//如果不在最后一页，显示向前和最后的页面连接
					if ($currentpage!=$totalpages) {
						$nextpage=$currentpage+1;
						echo '<li>
				           <a href="'.$_SERVER['PHP_SELF'].'?currentpage='.$nextpage.'" aria-label="Previous">
				             <span aria-hidden="true">&gt;</span>
				           </a> 
				         </li>';
				        echo '<li>
				           <a href="'.$_SERVER['PHP_SELF'].'?currentpage='.$totalpages.'" aria-label="Previous">
				             <span aria-hidden="true">&raquo;</span>
				           </a> 
				         </li>';
					}
	          ?>
				       </ul>
				     </nav>
			  </div>
			</div>
		</div>
	</section>
	<!-- 页脚 -->
	<footer class="footer">
		<div class="container text-center">
			<p class="">长春职业技术学院  信息技术分院 移动应用开发专业</p>
		</div>
	</footer>
	<!-- 模态框 -->
	<!-- 登录模态框 -->
	<div class="modal fade" id="login_form" tabindex="-1" role="dialog" aria-labelledby="login_form_title">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title" id="login_form_title">登录</h4>
	      </div>
	      <div class="modal-body">
	        <form>
	          <div class="form-group">
	            <label for="recipient-name" class="control-label">用户名：</label>
	            <input type="text" class="form-control" id="recipient-name">
	          </div>
	          <div class="form-group">
	            <label for="message-text" class="control-label">密码：</label>
	            <input type="text" class="form-control" id="message-text">
	          </div>
	        </form>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
	        <button type="button" class="btn btn-primary">登录</button>
	      </div>
	    </div>
	  </div>
	</div>
	<!-- 注册模态框 -->
	<div class="modal fade" id="register_form" tabindex="-1" role="dialog" aria-labelledby="register_form_title">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title" id="register_form_title">注册</h4>
	      </div>
	      <div class="modal-body">
	        <form>
	          <div class="form-group">
	            <label for="recipient-name" class="control-label">用户名：</label>
	            <input type="text" class="form-control" id="recipient-name">
	          </div>
	          <div class="form-group">
	            <label for="message-text" class="control-label">密码：</label>
	            <input type="text" class="form-control" id="message-text">
	          </div>
	        </form>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
	        <button type="button" class="btn btn-primary">注册</button>
	      </div>
	    </div>
	  </div>
	</div>
     <script src="lib/jquery/jquery.js"></script>
     <script src="lib/bootstrap/js/bootstrap.js"></script>
    </body>
</html>