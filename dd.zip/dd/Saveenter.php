<?php 
	session_start();
	header("content-type:text/html;charset=utf-8");
	include("conn.php");
	if (isset($_POST['submit'])&& $_POST['submit']=="登录") {
		// print_r($_POST);
		//exit;
		$check="select user from tb_reg where user='".$_POST['username']."'and password='".md5($_POST['pwd'])."'";
		// echo $check;
		$result=mysql_query($check,$conn);
		// var_dump($result);

		$info=mysql_num_rows($result);
		// echo $info;
		// exit;
		
		if($info>0){
			$_SESSION['user']=$_POST['username'];
			$_SESSION['password']=$_POST['password'];
			echo "<script>alert('登录成功!');window.location.href='index.php';</script>";	
		}else{
			echo "<script>alert('登录失败!密码或用户名错误.');history.back();</script>";
		}
	}
 ?>