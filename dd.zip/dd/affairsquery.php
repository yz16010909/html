<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
  <script>
  function chkinput_search(form){
    if (form.type.value=="") {
      alert("请输入查询条件!");
      form.type.focus();
      return false;
    }
    if (form.keyword.value=="") {
      alert("请输入查询关键字!");
      form.keyword.focus();
      return false;
    }
    return true;
  }
  </script>
</head>
<body>
  <div class="page-header">
  <h1>查询日记<small></small></h1>
</div>
<form class="form-inline" name="form" method="post" action="" onsubmit="return chkinput_seach(this)">
  <div class="form-group">
    <label for="exampleInputName2" >请选择查询方式</label>
    <select name="type" id="type" class="form-control">
      <option value="">请选择</option>
      <option value="1">主题</option>
      <option value="2">内容</option>
      <option value="3">分类</option>
    </select>
  </div>
  <div class="form-group" class="col-sm-10">
    <label for="keyword">请输入关键字</label>
    <input type="text" class="form-control" name="keyword" id="keyword" placeholder="关键字">
  </div>
  <button type="submit" name="Submit" class="btn btn-default" value="submit">查询</button>
</form>
<?php 
  include_once("conn.php");
  print_r($_POST);
  if(isset($_POST["Submit"]) && $_POST['Submit']!=""){
    $type=$_POST["type"];
    $keyword=$_POST["keyword"];
    if($type==1){
      $result=mysql_query("select * from tb_jour where rjzt like '$keyword%' order by id desc limit 1");
    }else if($type==2){
      $result=mysql_query("select * from tb_jour where fjnr like '$keyword%' order by id desc limit 1");
    }else if($type==3){
      $result=mysql_query("select * from tb_jour where rjfl like '$keyword%' order by id desc limit 1");
    }
  }


  // $sql="select * from tb_jour";
  // $result=mysql_query($sql);
  // var_dump($result);
  // while ($arr=mysql_fetch_assoc($result)) {
    // print_r($arr);
if($result==false){
  echo "<br><br><div align=center>对不起,没有查找到您要的内容!</div>";
}else{
  while($arr=mysql_fetch_array($result)){

 

?>
<div class="page-header">
              <h1><?php echo $arr['rjzt']; ?><small><?php echo $arr['time']; ?></small></h1>
            </div>
            <div class="media">
              <div class="media-left">
                <a href="#">
                  <img class="media-object" data-src="holder.js/20x20" alt="64x64" src="<?php echo $arr['xq']; ?>" data-holder-rendered="true" style="width: 64px; height: 64px;">
                </a>
              </div>
              <div class="media-body">
                <h4 class="media-heading">分类： <?php echo $arr['rjfl']; ?>    </h4>
               <p><?php echo $arr['fjnr']; ?></p>
              </div>
            </div>
<?php } 
}
?>
            

</body>
</html>