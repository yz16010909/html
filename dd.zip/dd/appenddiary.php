<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <title>主页</title>
        <!-- 链接bootstrap样式 -->
        <link rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/main.css">
    <!-- [if lt IE 9] -->
    <script src="lib/html5shiv/html5shiv.min.js"></script>
    <script src="lib/respond/respond.min.js"></script>
    <!-- [endif] -->
    </head>
    <body>
<div class="page-header">
  <h1>发表日记<small>记录生活</small></h1>
</div>
<form class="form-horizontal" name="form" method="post" action="chkappenddiary.php" onsubmit="return check_form(this)">
  <div class="form-group">
    <label for="topic" class="col-sm-2 control-label">日记主题</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="topic" name="topic" placeholder="日记主题">
    </div>
  </div>
  <div class="form-group">
    <label for="fl" class="col-sm-2 control-label">日记分类</label>
    <div class="col-sm-10">                
      <label class="radio-inline">
        <input type="radio" name="fl" id="inlineRadio1" value="工作" checked="checked"> 工作
      </label>
      <label class="radio-inline">
        <input type="radio" name="fl" id="inlineRadio2" value="心情"> 心情
      </label>
      <label class="radio-inline">
        <input type="radio" name="fl" id="inlineRadio3" value="情感"> 情感
      </label>
      <label class="radio-inline">
        <input type="radio" name="fl" id="inlineRadio4" value="热评"> 热评
      </label>
      <label class="radio-inline">
        <input type="radio" name="fl" id="inlineRadio5" value="实时"> 实时
      </label>
      <label class="radio-inline">
        <input type="radio" name="fl" id="inlineRadio6" value="杂记"> 杂记
      </label>
    </div>
  </div>
  <div class="form-group">
    <label for="check" class="col-sm-2 control-label">你现在的心情</label>
    <div class="col-sm-10">                
      <label class="radio-inline">
        <input type="radio" name="check" checked="checked" id="inlineRadio1" value="&lt;img src=images/xq/1.gif&gt;" checked="checked"> <img src="images/xq/1.gif" width="32" height="32">
      </label>  
      <label class="radio-inline">
        <input type="radio" name="check" id="inlineRadio1" value="&lt;img src='images/xq/2.gif'&gt;" > <img src="images/xq/2.gif" width="32" height="32">
      </label>  
      <label class="radio-inline">
        <input type="radio" name="check" id="inlineRadio1" value="&lt;img src='images/xq/3.gif'&gt;" > <img src="images/xq/3.gif" width="32" height="32">
      </label>  
      <label class="radio-inline">
        <input type="radio" name="check" id="inlineRadio1" value="&lt;img src='images/xq/4.gif'&gt;" > <img src="images/xq/4.gif" width="32" height="32">
      </label>  
      <label class="radio-inline">
        <input type="radio" name="check" id="inlineRadio1" value="&lt;img src='images/xq/5.gif'&gt;" > <img src="images/xq/5.gif" width="32" height="32">
      </label>  
      <label class="radio-inline">
        <input type="radio" name="check" id="inlineRadio1" value="&lt;img src='images/xq/6.gif'&gt;" > <img src="images/xq/6.gif" width="32" height="32">
      </label>  
      <label class="radio-inline">
        <input type="radio" name="check" id="inlineRadio1" value="&lt;img src='images/xq/7.gif'&gt;" > <img src="images/xq/7.gif" width="32" height="32">
      </label>  
      <label class="radio-inline">
        <input type="radio" name="check" id="inlineRadio1" value="&lt;img src='images/xq/8.gif'&gt;" > <img src="images/xq/8.gif" width="32" height="32">
      </label>  
      <label class="radio-inline">
        <input type="radio" name="check" id="inlineRadio1" value="&lt;img src='images/xq/9.gif'&gt;" > <img src="images/xq/9.gif" width="32" height="32">
      </label>  
      <label class="radio-inline">
        <input type="radio" name="check" id="inlineRadio1" value="&lt;img src='images/xq/10.gif'&gt;" > <img src="images/xq/10.gif" width="32" height="32">
      </label>  
      <label class="radio-inline">
        <input type="radio" name="check" id="inlineRadio1" value="&lt;img src='images/xq/11.gif'&gt;" > <img src="images/xq/11.gif" width="32" height="32">
      </label>  
    </div>
  </div>
  <div class="form-group">
    <label for="rjnr" class="col-sm-2 control-label">日记内容</label>
    <div class="col-sm-10">
      <textarea name="rjnr" class="form-control" rows="6" placeholder="写点什么吧"></textarea>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <input name="submit" type="submit" class="btn btn-success" value="发表" >
      <input name="reset" type="reset" class="btn btn-success" value="重置">
    </div>
  </div>
</form>
<script language="javascript">
function check_form(form1){
    if(form1.topic.value==""){
      alert("日记主题不能为空！");form1.topic.focus();return false;
    }
    
    if(form1.rjnr.value=="")  {
      alert("内容不能为空!");form1.rjnr.focus();return false;
    }
}

</script>
 </body>
</html>