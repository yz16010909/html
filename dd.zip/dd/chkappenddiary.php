<?php 
header("content-type:text/html; charset=utf-8"); 
include_once('conn.php');
print_r($_POST);
if(is_file("./filename.txt")){
	$filter_woed=file("./filename.txt");
	// print_r($filter_woed);
	$str=$_POST['rjnr'];
	// echo $str;
	for($i=0;$i<count($filter_woed);$i++){
		if(preg_match("/".trim($filter_woed[$i])."/i", $str)){
			echo "<script>alert('有敏感词');history.bock(-1);</script>";
			exit;
		}
	}
}

		$zt=trim($_POST['topic']); //判断主体是否超过20个字
		if (strlen($zt)>40) {
			echo "<script>alert('主体字数不能超过20个汉字');history.back();</script>";
			exit;
		}
		$fl=$_POST['fl'];
		$mood=$_POST['check'];
		$nr=$_POST['rjnr'];
		$datetime=date("Y-m-d H:i:s");
		// $query="insert into tb_jour(rjzt,rjfl,rjnr,xq,time)values('$zt','$fl','$nr','$mood','$datetime')";
		// echo $query;
		// exit;
		if (mysql_query("insert into tb_jour(rjzt,rjfl,rjnr,xq,time)values('$zt','$fl','$nr','$mood','$datetime')",$conn)) {
			echo "<script>alert('日记添加成功！');history.back();</script>";
		}else{
			echo "<script>alert('日记添加失败！');history.back();</script>";
			exit;
		}

 ?>