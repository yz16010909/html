<?php 
header("content-type:text/html; charset=utf-8"); 
include_once('conn.php');
print_r($_POST);

		$str=$_POST['zcms'];
		$zt=$_POST['zcje']; 
		$mood=$_POST['zxsj'];
		$nr=$_POST['lb'];
		$datetime=date("Y-m-d H:i:s");
		// $query="insert into tb_outgo(zcms,zcje,zcsj,lb)values('$str','$zt','$datetime','$nr')";
		// echo $query;
		// exit;
		if (mysql_query("insert into tb_outgo(zcms,zcje,zcsj,lb)values('$str','$zt','$datetime','$nr')",$conn)) {
			echo "<script>alert('添加成功！');history.back();</script>";
		}else{
			echo "<script>alert('添加失败！');history.back();</script>";
			exit;
		}

 ?>