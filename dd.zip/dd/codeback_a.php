<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <title>梦幻网络日记</title>
        <!-- 链接bootstrap样式 -->
        <link rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/enter.css">
		<!-- [if lt IE 9] -->
		<script src="lib/html5shiv/html5shiv.min.js"></script>
		<script src="lib/respond/respond.min.js"></script>
		<!-- [endif] -->
		
    </head>
    <body>
   	<div class="container">
   		<div class="bg" style="padding-top:150px;">
   			<div class="page-header">
   			  <h1 class="text-center"><small>新密码设置</small></h1>
   			</div>
   
	   		<form id="form" name="form1" method="post" action="savecodeback_a.php" class="form-horizontal" onSubmit="return chkinputlogin(this)">
	   		  
	   		  <div class="form-group">
	   		    <label for="passx" class="col-sm-3 control-label">填写新密码</label>
	   		    <div class="col-sm-9">
	   		      <input name="passx" type="password" class="form-control" placeholder="Password">
	   		      <input type="hidden" name="user" value="<?php echo $_GET["use"] ?>">
	   		    </div>
	   		  </div>
	   		  <div class="form-group">
	   		    <label for="mbda" class="col-sm-3 control-label">确认新密码</label>
	   		    <div class="col-sm-9">
	   		      <input name="mbda" type="password" class="form-control" placeholder="Password">
	   		    </div>
	   		  </div>
	   		  <div class="form-group">
	   		    <div class="col-sm-offset-3 col-sm-9">
	   		      <input name="submit" type="submit" class="btn btn-success" value="提交">
	   		      <input name="reset" type="reset" class="btn btn-success" value="重置">
	   		    </div>
	   		  </div>
	   		</form>
    	</div>
   	</div>


    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.min.js"></script>
    <script>
			function chkinputlogin(form1){
			if (form1.passx.value=="") {
				alert("请输入用户名");
				form1.passx.focus();
				return(false);
			}
			if(form1.mbda.value==""){
				alert("请输入密码");
				form1.mbda.focus();
				return(false);
			}
			return(true);
		}
		</script>
    </body>
</html>