<?php 
	$conn=mysql_connect("localhost","root","root")or die ("connect mysql false");
	//连接数据库服务器
	mysql_select_db("db_diary",$conn)or die ("connect database false");
	//连接制定的数据库
	mysql_query("set names utf8");
	//避免乱麻
 ?>