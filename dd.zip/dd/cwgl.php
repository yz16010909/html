<?php 
  include_once("conn.php");
  $sql="select * from tb_income,tb_outgo";
  $result=mysql_query($sql);
  // var_dump($result);
  while ($arr=mysql_fetch_assoc($result)) {
    // print_r($arr);

 ?>

<div class="page-header">
              <h1>收入</h1>
              <p>收入描述:<?php echo $arr['srms']; ?></p>
              <p>收入金额:<?php echo $arr['srje']; ?></p>
              <p>收入类别:<?php echo $arr['lb']; ?></p>
              <p>收入时间:<?php echo $arr['srsj']; ?></p>
              <h1>支出</h1>
              <p>支出描述:<?php echo $arr['zcms']; ?></p>
              <p>支出金额:<?php echo $arr['zcje']; ?></p>
              <p>支出类别:<?php echo $arr['lb']; ?></p>
              <p>支出时间:<?php echo $arr['zcsj']; ?></p>
            </div>
<?php } ?>
            
