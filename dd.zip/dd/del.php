<?php 
header("content-type:text/html; charset=utf-8"); 

		include('conn.php');
		$strid=$_GET['id'];
		$sql=mysql_query('delete from tb_jour where id='.$strid);
		if($sql){
			
			echo " <script>alert('删除成功!');window.location.href='index.php';</script> ";
			mysql_free_result($sql); //?
			mysql_close($coon1);
		}
	 ?>