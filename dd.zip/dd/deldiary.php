<?php 
  include_once("conn.php");
  $sql="select * from tb_jour";
  $result=mysql_query($sql);
  // var_dump($result);
  while ($arr=mysql_fetch_assoc($result)) {
 ?>
<div class="page-header">
              <h1><?php echo $arr['rjzt']; ?><small><?php echo $arr['time']; ?></small></h1>
            </div>
            <div class="media">
              <div class="media-left">
                <a href="#">
                  <img class="media-object" data-src="holder.js/20x20" alt="64x64" src="<?php echo $arr['xq']; ?>" data-holder-rendered="true" style="width: 64px; height: 64px;">
                </a>
              </div>
              <div class="media-body">
                <h4 class="media-heading">分类： <?php echo $arr['rjfl']; ?>    </h4>
               <p><?php echo $arr['fjnr']; ?></p>
              </div>
              <a href="del.php?id=<?php echo $arr['id'] ?>" class="btn btn-primary">修改</a>
            </div>
<?php } ?>
            
