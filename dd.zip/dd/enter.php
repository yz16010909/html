<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <title>梦幻网络日记</title>
        <!-- 链接bootstrap样式 -->
        <link rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/enter.css">
		<!-- [if lt IE 9] -->
		<script src="lib/html5shiv/html5shiv.min.js"></script>
		<script src="lib/respond/respond.min.js"></script>
		<!-- [endif] -->
		<script>
		function chkinputlogin(form){
			if (form1.username.value=="") {
				alert("请输入用户名");
				form1.user.focus();
				return(false);
			}
			if(form1.password.value==""){
				alert("请输入密码");
				form1.password.focus();
				return(false);
			}
			return(true);
		}
		</script>
    </head>
    <body>
   	<div class="container">
   		<div class="bg">
	   		<form id="form" name="form1" method="post" action="Saveenter.php" class="form-horizontal">
	   		  <div class="form-group">
	   		    <label for="user" class="col-sm-2 control-label">UserName</label>
	   		    <div class="col-sm-10">
	   		      <input type="text" name="username" id="user" class="form-control" placeholder="UserName">
	   		    </div>
	   		  </div>
	   		  <div class="form-group">
	   		    <label for="pwd" class="col-sm-2 control-label">Password</label>
	   		    <div class="col-sm-10">
	   		      <input name="pwd" type="password" class="form-control" id="pwd" placeholder="Password">
	   		    </div>
	   		  </div>
	   		  <div class="form-group">
	   		    <div class="col-sm-offset-2 col-sm-10">
	   		      <input name="submit" type="submit" class="btn btn-success" value="登录" onclick="return chkinputlogin()">
	   		      <a class="btn btn-primary" href="reg.php">注册</a>
	   		      <a class="btn btn-warning pull-right" href="codeback.php">忘记密码</a>
	   		    </div>
	   		  </div>
	   		</form>
    	</div>
   	</div>


    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.min.js"></script>
    </body>
</html>