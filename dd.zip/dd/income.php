<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <title>主页</title>
        <!-- 链接bootstrap样式 -->
        <link rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/main.css">
    <!-- [if lt IE 9] -->
    <script src="lib/html5shiv/html5shiv.min.js"></script>
    <script src="lib/respond/respond.min.js"></script>
    <!-- [endif] -->
    </head>
    <body>
<div class="page-header">
  <h1>添加收入<small>记录每一份收入</small></h1>
</div>
<form class="form-horizontal" name="form1" method="post" action="chkincome.php" onsubmit="return check_form(this)">
  <div class="form-group">
    <label for="srms" class="col-sm-2 control-label">收入描述</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="srms" name="srms" placeholder="收入描述">
    </div>
  </div>
  <div class="form-group">
    <label for="srje" class="col-sm-2 control-label">收入金额</label>
    <div class="col-sm-10">
      <input type="number" class="form-control" id="srje" name="srje" placeholder="收入金额">
    </div>
  </div>
  <div class="form-group">
    <label for="check" class="col-sm-2 control-label">收入类别</label>
    <div class="col-sm-10">                
      <label class="radio-inline">
        <input type="radio" name="lb" checked="checked" id="inlineRadio1" value="汇款" checked="checked"> 汇款
      </label>  
      <label class="radio-inline">
        <input type="radio" name="lb" id="inlineRadio1" value="奖金" > 奖金
      </label>  
      <label class="radio-inline">
        <input type="radio" name="lb" id="inlineRadio1" value="补助" > 补助
      </label>  
      <label class="radio-inline">
        <input type="radio" name="lb" id="inlineRadio1" value="工资" > 工资
      </label>  
      <label class="radio-inline">
        <input type="radio" name="lb" id="inlineRadio1" value="其他" > 其他
      </label>  
    </div>
  </div>
  <div class="form-group">
    <label for="srsj" class="col-sm-2 control-label">收入时间</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="srsj" name="srsj" placeholder="收入时间">
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <input name="submit" type="submit" class="btn btn-success" value="发表" >
      <input name="reset" type="reset" class="btn btn-success" value="重置">
    </div>
  </div>
</form>
<script language="javascript">
function check_form(form1){
    if(form1.srms.value==""){
      alert("日记主题不能为空！");form1.srms.focus();return false;
    }
    
   
    if(form1.lb.value=="")  {
      alert("内容不能为空!");form1.lb.focus();return false;
    }
    if(form1.srje.value=="")  {
      alert("内容不能为空!");form1.srje.focus();return false;
    }
}

</script>
 </body>
</html>