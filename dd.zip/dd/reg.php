<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <title>梦幻网络日记</title>
        <!-- 链接bootstrap样式 -->
        <link rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/enter.css">
		<!-- [if lt IE 9] -->
		<script src="lib/html5shiv/html5shiv.min.js"></script>
		<script src="lib/respond/respond.min.js"></script>
		<!-- [endif] -->

		<script>
		function chkinput(form){
			if(form1.usernc.value==""){
				alert("请输入用户密码!");
				form1.usernc.focus();
				return false;
			}
			if(form1.userpwd.value==""){
				alert("请输入注册密码!");
				form1.userpwd.focus();
				return false;
			}
			if (form1.userpwd1.value=="") {
				alert("请输入重复密码!");
				form1.userpwd1.focus();
				return(false);
			}
			if (form1.userpwd.value!=form.userpwd1.value) {
				alert("密码与确认密码不同!");
				form1.userpwd.focus();
				return(false);
			}
			if (form1.userpwd.value.leng<6) {
				alert("密码长度不小于6位");
				form1.userpwd.focus();
				return(false);
			}
			if (form1.truename.value=="") {
			alert("请输入真实姓名!");
			form1.truename.focus();
			return(false);
			}
			if (form1.sex.value=="") {
				alert("请输入性别!");
				form1.sex.focus();
				return(false);
			}
			if (form1.mb.value=="") {
				alert("请输入密保问题!");
				form1.mb.focus();
				return(false);
			}
			if (form1.mbda.value=="") {
				alert("请输入密保答案!");
				form1.mbda.focus();
				return(false);
			}
			return(true);
		}
		</script>
    </head>
    <body>
   	<div class="container">
   		<div class="bg" style="padding-top:200px;">
   
	   		<form id="form1" name="form1" method="post" action="Savereg.php" class="form-horizontal">
	   		  <div class="form-group">
	   		    <label for="user" class="col-sm-3 control-label">用户昵称</label>
	   		    <div class="col-sm-9">
	   		      <input type="text" name="usernc" class="form-control" placeholder="UserName">
	   		    </div>
	   		  </div>
	   		  <div class="form-group">
	   		    <label for="pwd" class="col-sm-3 control-label">密码</label>
	   		    <div class="col-sm-9">
	   		      <input name="userpwd" type="password" class="form-control" placeholder="Password">
	   		    </div>
	   		  </div>
	   		  <div class="form-group">
	   		    <label for="pwd" class="col-sm-3 control-label">重复密码</label>
	   		    <div class="col-sm-9">
	   		      <input name="userpwd1" type="password" class="form-control" placeholder="Password">
	   		    </div>
	   		  </div>
	   		  <div class="form-group">
	   		    <label for="user" class="col-sm-3 control-label">真实姓名</label>
	   		    <div class="col-sm-9">
	   		      <input type="text" name="truename" class="form-control" placeholder="TrueName">
	   		    </div>
	   		  </div>
	   		  <div class="form-group">
	   		    <label for="user" class="col-sm-3 control-label">性别</label>
	   		    <div class="col-sm-9">
	   		      <label class="radio-inline">
		   		    <input type="radio" name="sex" id="sex" value="男">男
		   		  </label>
		   		  <label class="radio-inline">
		   		    <input type="radio" name="sex" id="sex" value="女"> 女
		   		  </label>
	   		    </div>
	   		  </div>
	   		  
	   		  <div class="form-group">
	   		    <label for="mb" class="col-sm-3 control-label">密保问题</label>
	   		    <div class="col-sm-9">
	   		      <input name="mb" type="text" class="form-control" placeholder="question">
	   		    </div>
	   		  </div>
	   		  <div class="form-group">
	   		    <label for="mbda" class="col-sm-3 control-label">密保答案</label>
	   		    <div class="col-sm-9">
	   		      <input name="mbda" type="text" class="form-control" placeholder="answer">
	   		    </div>
	   		  </div>
	   		  <div class="form-group">
	   		    <div class="col-sm-offset-3 col-sm-9">
	   		      <input name="submit" type="submit" class="btn btn-success" value="注册" onclick="return chkinput()">
	   		      <input name="reset" type="reset" class="btn btn-success" value="重置">
	   		    </div>
	   		  </div>
	   		</form>
    	</div>
   	</div>


    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.min.js"></script>
    </body>
</html>