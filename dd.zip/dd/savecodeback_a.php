<?php 
	session_start();
	header('content-type:text/html;charset=utf-8');
	include('conn.php');
	if (isset($_POST['submit'])&& $_POST['submit']=="提交") {
		if ($_POST['user']!="") {		//判断用户昵称是否为空
				echo "string";
			$sql="update tb_reg set password='".md5($_POST['passx'])."' where user='".$_POST['user']."'"; //更新密码
			$result=mysql_query($sql,$conn);
			if ($result) {
				echo "<script>alert('修改密码成功!');window.location.href='enter.php';</script>";
			}else{
				echo "<script>alert('密码修改失败!');history.back();</script>";
			}
		}
	}
 ?>