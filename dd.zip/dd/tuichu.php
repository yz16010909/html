<?php
header("content-type:text/html; charset=utf-8"); 
session_destroy();
echo "<script>alert('退出成功!');window.location.href='enter.php';</script> ";
?>