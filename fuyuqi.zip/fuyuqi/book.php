<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
<?php 
	$conn=mysql_connect('localhost','root','root');		//打开服务器
	mysql_select_db('db_bookstore',$conn);		//选择数据库
	mysql_query("set names utf8");		//修改字符集
	$select=mysql_query("select * from tb_books");		//定义输出的表

 ?>
	<table width="200" border="1">
  <tr>
    <td align="center">id</td>
    <td align="center">number</td>
    <td align="center">bookname</td>
     <td align="center">publish</td>
      <td align="center">price</td>
  </tr>
  <?php while ($array=mysql_fetch_array($select)) {?>
  		//定义数组，将之前输出的表。
  <tr>
    <td> <?php echo $array['id']; ?> </td>
    <td> <?php echo $array['number']; ?> </td>
    <td> <?php echo $array['bookname']; ?> </td>
    <td> <?php echo $array['publish']; ?> </td>
    <td> <?php echo $array['price']; ?> </td>
    //数组输出，单个
  </tr>
  <?php  }  ?>
</table>
</body>
</html>