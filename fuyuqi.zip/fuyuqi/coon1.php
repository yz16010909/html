<?php 
	$conn=mysql_connect('localhost','root','root');
	mysql_select_db("db_bookstore",$conn);
	mysql_query("set names utf8");
 ?>