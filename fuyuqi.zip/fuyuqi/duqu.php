<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
<?php 
include('conn.php');
$select=mysql_query("select * from tb_user",$conn);
$array=mysql_fetch_array($select)
 ?>
<table width="200" border="1">
  <tr>
    <td align="center">id</td>
    <td align="center">姓名</td>
    <td align="center">密码</td>
  </tr>
	<?php 
		while ($array){	
	 ?>
  <tr>
    <td><?php  echo $array['id']; ?></td>
    <td><?php  echo $array['name']; ?></td>
    <td><?php  echo $array['pwd']; ?></td>
  </tr>
  <?php  } ?>
</table>
</body>
</html>