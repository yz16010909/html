<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<?php 
		$link=mysql_connect('localhost','root','root') or die('连接失败'.mysql_error());
		$l=mysql_select_db("db_login",$link);
		if ($link) {
			echo "yes <br>";
		}else{
			echo "no <br>";
		}
		if ($l) {
			echo "yess <br>";
		}else{
			echo "noo <br>";
		}
	 ?>
</body>
</html>