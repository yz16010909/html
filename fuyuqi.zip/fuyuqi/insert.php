<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<style>
		form{
			border: 1px solid #ccc;
			border-radius: 5px;
		}
		h2{
			width: 50%;
			margin: 10px auto;
			background: #0066ff;
			border-radius: 5px;
			color: #fff;
		}
	</style>
	<script>
		function check(){
			if(form1.number.value==""){
				alert("请输入书号!");
				form1.number.focus();
				return false;
			}
			if(form1.bookname.value==""){
				alert("请输入书名!");
				form1.bookname.focus();
				return false;
			}
			if(form1.publish.value==""){
				alert("请输入出版社!");
				form1.publish.focus();
				return false;
			}
			if(form1.price.value==""){
				alert("请输入定价!");
				form1.price.focus();
				return false;
			}
			form1.submit();
		}
	</script>
</head>
<body>
	<?php 
		include('coon1.php');
		if($_POST['submit']){
			$number=$_POST['number'];
			$bookname=$_POST['bookname'];
			$publish=$_POST['publish'];
			$price=$_POST['price'];
			$sql=mysql_query("insert into tb_books(number,bookname,publish,price) values('$number','$bookname','$publish','price')");
			echo "<script> alert('图书记录添加成功!');window.location.href='tushu.php';</script>";	//win.位置.href....
			mysql_free_result($sql); //自由结果
			mysql_close($coon1);
		}
	 ?>
	<form action="" id="form1" name="form1" align="center" method="post">
	 	<h2 align="center" height="51">添加图书记录</h2>
	 
		 <p>
			<label for="">书&nbsp;&nbsp;&nbsp;号:</label>
			<input type="text" name="number" id="number">
		</p>
		<p>
			<label for="">书&nbsp;&nbsp;&nbsp;名:</label>
			<input type="text" name="bookname" id="bookname">
		</p>
		<p>
			<label for="">出版社:</label>
			<input type="text" name="publish" id="publish">
		</p>
		<p>
			<label for="">定&nbsp;&nbsp;&nbsp;价:</label>
			<input type="text" name="price" id="price">
		</p>
		<p align="center">
			<input type="submit" name="submit" id="submit" value="提交" onclick="return check()">
			&nbsp;&nbsp;&nbsp;
			<input type="reset" name="reset" id="reset" value="重置">
		</p>
	</form>
</body>
</html>