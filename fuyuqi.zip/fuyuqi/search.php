<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<style>
		form{
			border: 1px solid #ccc;
			border-radius: 5px;
		}
		h2{
			width: 50%;
			margin: 10px auto;
			background: #0066ff;
			border-radius: 5px;
			color: #fff;
		}
	</style>
	
</head>
<body>
	<?php 
		include('coon1.php');
		
	 ?>
		<form action="" id="form1" name="form1" align="center" method="post">
	 	<h3 align="center">请输入图书名称:	
	 	<input type="text"  name="bookname" id="bookname">
	 	<input type="submit" name="submit" id="submit" value="查询">	</h3>
	 	</form>

		<table width="100%" border="1" align="center">
	  <tr>
	    <td align="center">序号</td>
	    <td align="center">书号</td>
	    <td align="center">书名</td>
	    <td align="center">出版社</td>
	    <td align="center">价格</td>
	  </tr>
	  <?php 
	  	$sql=mysql_query("select * from tb_books");
	  	$info=mysql_fetch_array($sql);
	  	if($_POST['submit']=='查询'){
	  		$bookname=$_POST['bookname'];
	  		$sql=mysql_query("select * from tb_books where bookname like '%".$bookname."%'");
	  		$info=mysql_fetch_array($sql); 		
	  	}
	  	if($info==false){
	  		echo "<div align='center' style='color:#ff0000;font-size:12px'>对不起，您检索的图书信息不存在！</div>";
	  	}
	   ?>
	   <?php 
	   do{
	    ?>
	  <tr>
	    <td align="center"><?php echo $info['id']; ?></td>
	    <td align="center"><?php echo $info['number']; ?></td>
	    <td align="center"><?php echo $info['bookname']; ?></td>
	    <td align="center"><?php echo $info['publish']; ?></td>
	    <td align="center"><?php echo $info['price']; ?></td>
	  </tr>
		<?php 
			}while($info=mysql_fetch_array($sql))
		 ?>
	
</body>
</html>