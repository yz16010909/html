<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	<title>Document</title>
	<style>
	*{
		margin: 0;
		padding: 0;
	}
	p>a{
		margin: 0 10px;
	}
	</style>
</head>
<body>
<?php 
	include('coon1.php');  //插入
	// $sql=mysql_query("select * from tb_books");  //定义显示列表
  if(isset($_GET['page'])){
    $page=$_GET['page'];
  }else{
    $page=1;
  }
  if($page){
    $page_size=3;
    $result=mysql_query("select * from tb_books");
    $message_count=mysql_num_rows($result);
    $page_count=ceil($message_count/$page_size);
    $offset=($page-1)*$page_size;
    $sql=mysql_query("select * from tb_books order by id desc limit $offset,$page_size");
  }
 ?>
	<h1 align="center">图书信息管理系统</h1>
	<p align="right"><a href="insert.php">添加图书记录</a><a href="search.php">图书信息搜索</a></p>
	<table width="100%" border="1" align="center">
  <tr>
    <td align="center">序号</td>
    <td align="center">书号</td>
    <td align="center">书名</td>
    <td align="center">出版社</td>
    <td align="center">价格</td>
    <td align="center">操作</td>
  </tr>
  <?php while($info=mysql_fetch_array($sql)){ ?>  
  <!-- 定义,将列表转换成数组 -->
  <tr>
    <td align="center"><?php echo $info['id']; ?></td>
    <td align="center"><?php echo $info['number']; ?></td>
    <td align="center"><?php echo $info['bookname']; ?></td>
    <td align="center"><?php echo $info['publish']; ?></td>
    <td align="center"><?php echo $info['price']; ?></td>
    <td align="center"><a href="update.php?id=<?php echo $info['id']; ?>">修改</a>/<a href="delete.php?id=<?php echo $info['id']; ?>" onclick="return confirm('确定删除？')">删除</a></td>
  </tr>
  <?php } ?>
</table>


  <p align="center">
<?php  
  if($page!=1){
  ?>
    <a href="tushu.php?page=1">首页</a>
    <a href="tushu.php?page=<?php echo $page-1; ?>">上一页</a>
  <?php 
    }
  if($page<$page_count){
 ?>
    <a href="tushu.php?page=<?php echo $page+1; ?>">下一页</a>
    <a href="tushu.php?page=<?php echo $page_count;?>">末页</a>
  <?php } ?>
    当前 <?php echo $page; ?>  页
    共 <?php echo $page_count; ?> 页
    总 <?php echo $message_count; ?> 条数
  </p>

</body>
</html>