<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>添加用户信息</title>
</head>
<body>
	<section>
		<form id="form1" name="form1" method="post" action="form_ok.php">
			<h1>手机使用调查表</h1>
			<p>
  			<label for="name">姓名:</label>
  			<input type="text" name="name" id="name" />
  			</p>
  			<p>
  			<label for="radio">性别:</label>
  			<input type="radio" name="radio" id="radio" value="男" />
  			<label for="radio">男</label>
 			<input type="radio" name="radio" id="radio" value="女" />
 			<label for="radio">女</label>
  			</p>
  			<p>
  			<label for="password">密码:</label>
  			<input type="text" name="password" id="password" />
  			</p>
  			<p>
  			<label for="Address">住址:</label>
  			<input type="text" name="Address" id="Address" />
  			</p>
  			<p>
  			<label for="Email">邮箱:</label>
  			<input type="email" name="Email" id="Email" />
  			</p>
  			<p>
  				<input type="submit" name="button" id="button" value="提交" />
  				<input type="reset" name="button1" id="button1" value="取消" />
  			</p>
		</form>		
	</section>
</body>
</html>