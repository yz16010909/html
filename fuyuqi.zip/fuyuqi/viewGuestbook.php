<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>查看留言</title>
<link href="incs/default.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php 
    include('conn.php');
    if($_GET['page']){
        $page=$_GET['page'];
    }else{
        $page=1;
    }
    if($page){
        $page_size=3;   //一行有几个
        $sel=mysql_query("select * from guestbook"); //为下面的总条数做准备
        $message_count=mysql_num_rows($sel);    //条数
        $page_count=ceil($message_count/$page_size);    //总页数 
        $offset=($page-1)*$page_size;   
        $sql=mysql_query("select * from guestbook order by note_id desc limit $offset,$page_size");
    }
 ?>
<center>
    <div id="div_wrap1">
        <div id="div_header">
            <div id="menu1"><img src="images/ip.gif" />加入收藏&nbsp; <img src="images/mail.gif" />联系我们</div>
            <div id="menu2">
                <ul>
                    <li><img src="images/note.gif" /><a href="addGuestbook.php">我要留言</a></li>
                    <li><img src="images/view.gif" /><a href="viewGuestbook.php">查看留言</a></li>
                    <li><img src="images/admin.gif" /><a href="admin/login.php">留言管理</a></li>
                </ul>
            </div>
        </div>
        <?php while($info=mysql_fetch_array($sql)){ ?>
        <div id="div_content">
            <div class="title">
                <ul>
                    <li>留言者：</li>
                    <li>TIME：： </li>
                    <li><img src="images/from.gif" /> <img src="images/qq.gif" /> <img src="images/mail.gif" /> <img src="images/tel.gif" /> <img src="images/ip.gif" /></li>                    
                </ul>
            </div>
            <div class="content">
                <div class="div_img"><img src="" width="90" height="90" alt="user" class="userpic" /></div>
                <div class="div_info">
                    <ul>
                        <li>留言标题：</li>
                        <li>：</li>
                        <li><u>留言回复：</u></li>
                        <li>
                            <p>回复时间:&nbsp;|&nbsp;回复作者：</p>
                            <p>&nbsp;</p>
                        </li>
                    </ul>
                </div>
            </div> 
             <?php } ?>      
            <div class="pagemenu"><span>&nbsp;&nbsp;&nbsp;</span></div>
        </div>
       
        <div id="div_footer"><img src="images/icon.gif" >&nbsp;Copyright &copy; 2010 Note.com Ltd. All Rights Reserved. 版权所有</div>
    </div>
    </div>
</center>
</body>
</html>
